# NBA Moneyball 2.0: Predicting the Next All‑NBA Selections

This project aims to build a reproducible end‑to‑end data pipeline and machine‑learning stack for predicting which NBA players are most likely to make an **All‑NBA** team in the following season.  Starting from raw seasonal data pulled from [Basketball‑Reference](https://www.basketball-reference.com/), we engineer features, train interpretable models, evaluate them in a rolling time‑series setting, and expose the results through an interactive Streamlit application.

## Project Goals

* **Data collection** – Automatically ingest per‑season box score and advanced player statistics for every year from 2000–01 through the most recently completed season.  The [`basketball_reference_web_scraper`](https://jaebradley.github.io/basketball_reference_web_scraper/) library can be installed from PyPI with `pip install basketball_reference_web_scraper`【35430849402446†L50-L55】, supports seasons after 1999–2000【35430849402446†L62-L63】 and provides convenient helpers like `client.players_season_totals` and `client.players_advanced_season_totals`【828354442439533†L304-L381】.
* **Label generation** – Scrape historical **All‑NBA** First/Second/Third team selections from Basketball‑Reference’s All‑League page and create binary targets for whether a player was selected in a given season and whether they will be selected in the following season.
* **Feature engineering** – Build a normalized master table where each row represents a unique player‑season.  Features include core per‑game and advanced stats, biographical attributes (age, position), engineered interactions (e.g. `PTS × AST`, `STL × BLK`, `USG% × TS%`, `MP × BPM`), and experience (`Years_in_League`).
* **Modeling** – Train a balanced logistic regression baseline and a tuned gradient boosting model (e.g. XGBoost) to predict *All‑NBA* selection in season *Y+1* given stats from season *Y*.  Use a rolling window evaluation strategy: train through season *N‑1* and test on season *N* for years 2010 onward.  Report F1, precision, recall, ROC‑AUC and PR‑AUC.
* **Interpretation** – Compute global feature importances using SHAP values (or XGBoost’s built‑in contribution scores) and provide example explanations for individual players.
* **Visualization** – Deliver a Streamlit app with three pages:
  1. **Model Insights** – Global feature importance bar chart, evaluation metrics and confusion matrix for the last test season.
  2. **Player Profile Explorer** – Inspect any player‑season’s stats and compare to the All‑NBA average for that year with a radar chart.
  3. **Future Stars Predictor** – List the top players who did *not* make an All‑NBA team in the most recent season but have the highest predicted probability of doing so next year; display probabilities vs. VORP in a scatter plot.

## Repository Structure

```text
.
├── data/
│   ├── raw/             # Season‑level pulls and All‑NBA selections (generated)
│   └── processed/       # Master table and train/test splits (generated)
├── notebooks/           # Exploratory analysis and reporting notebooks
├── src/
│   ├── data/
│   │   ├── ingest_bref.py     # Pull per‑season stats using the web scraper
│   │   └── build_master.py    # Assemble and clean the master dataset
│   ├── features/
│   │   └── feature_engineering.py # Generate interaction features and scaling
│   ├── models/
│   │   ├── train.py            # Train models with time‑series splits
│   │   ├── evaluate.py         # Compute evaluation metrics and aggregate results
│   │   └── shap_analysis.py    # Compute global and local explanations
│   └── app/
│       ├── streamlit_app.py    # Streamlit UI entry point
│       └── utils.py            # Helper functions for the app
├── reports/
│   ├── figures/         # Generated plots (SHAP, ROC curves, radar charts)
│   └── metrics.json     # Serialized evaluation results
├── tests/               # Unit tests for critical utilities
├── requirements.txt     # Python dependencies (pinned versions)
├── Makefile             # Convenience targets: make data, make train, make app
├── LICENSE              # MIT license
└── README.md            # Project overview, methods and insights
```

## Quick Start

1. **Clone the repository**

   ```bash
   git clone https://github.com/your‑username/nba-moneyball-2-0-all-nba-predictor.git
   cd nba-moneyball-2-0-all-nba-predictor
   ```

2. **Install dependencies**

   We recommend using a Python ≥3.10 virtual environment.  Dependencies are pinned in `requirements.txt`.  Install them with:

   ```bash
   python -m venv env
   source env/bin/activate
   pip install -r requirements.txt
   ```

   The [`basketball_reference_web_scraper`](https://jaebradley.github.io/basketball_reference_web_scraper/) package is available from PyPI and provides helper functions to download player totals and advanced stats【828354442439533†L304-L381】.

3. **Run the data pipeline**

   The Makefile exposes high‑level targets.  For example, to fetch raw data and build the processed master table:

   ```bash
   make data START_YEAR=2000 END_YEAR=2025
   ```

   To train models and compute evaluation metrics:

   ```bash
   make train
   ```

4. **Launch the Streamlit app**

   After training, start the interactive dashboard locally:

   ```bash
   make app
   # or directly
   streamlit run src/app/streamlit_app.py
   ```

## Insights Summary

This section will be populated after running the full pipeline.  It will summarize:

* **Top predictive features** – The five most important variables driving All‑NBA selection next season (from SHAP/global importances).
* **Breakout candidates** – Five players from the most recently completed season who did not make an All‑NBA team but have the highest predicted probability of doing so next year.
* **Model performance** – Final test‑season metrics (F1, precision, recall, ROC‑AUC, PR‑AUC) and a discussion of the trade‑offs between the baseline and boosted models.

## Data Sources and Credits

All player statistics and award data come from [Basketball‑Reference](https://www.basketball-reference.com/).  The ingestion scripts use the community‑maintained [`basketball_reference_web_scraper`](https://jaebradley.github.io/basketball_reference_web_scraper/) package, which can be installed via pip【35430849402446†L50-L55】 and supports scraping seasons after 1999–2000【35430849402446†L62-L63】.  Please respect their rate limits and terms of use when downloading data【35430849402446†L45-L73】.

## Contributing

Contributions are welcome!  Please open an issue or submit a pull request for bug fixes, feature requests, or improvements.  This project is licensed under the MIT License—see [LICENSE](LICENSE) for details.